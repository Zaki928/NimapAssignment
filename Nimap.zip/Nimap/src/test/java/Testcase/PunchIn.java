package Testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class PunchIn {
	
	
	@Test(dependsOnMethods = {"loginTest"})
	public void punchInTest() {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
        driver = new ChromeDriver();
        driver.get(" https://testffc.nimapinfotech.com/");
	    WebElement punchInButton = driver.findElement(By.id("punchInButton"));
	    punchInButton.click();

	    WebElement toastMessage = driver.findElement(By.id("toastMessage"));
	    Assert.assertTrue(toastMessage.isDisplayed(), "Toast message not displayed after punch-in.");
	    Assert.assertEquals(toastMessage.getText(), "Punch-in successful", "Unexpected toast message.");
	}


	
	
}
