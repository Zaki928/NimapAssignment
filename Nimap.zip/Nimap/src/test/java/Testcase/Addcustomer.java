package Testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Addcustomer {
	
	@DataProvider(name = "customerData")
	public Object[][] customerDataProvider() {
	    return new Object[][] {
	        {"Customer A", "customerA@example.com"},
	        {"Customer B", "customerB@example.com"},
	        {"Customer C", "customerC@example.com"}
	    };
	}

	@Test(dataProvider = "customerData")
	public void addCustomerTest(String customerName, String customerEmail) {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
        driver = new ChromeDriver();
        driver.get(" https://testffc.nimapinfotech.com/");

        driver.findElement(By.xpath("//*[@placeholder=\"Email Id / Mobile No\"]")).sendKeys("abc@gmail.com");
        driver.findElement(By.xpath("//*[@placeholder=\"Password\"]")).sendKeys("1234");
        driver.findElement(By.xpath("//*[@formcontrolname=\"captchaValue\"]")).sendKeys("IIACF6");
        driver.findElement(By.id("(//*[@class=\"btn btn-primary btn-elevate kt-login__btn-primary\"])[1]")).click();
	    WebElement addCustomerButton = driver.findElement(By.id("addCustomerButton"));
	    addCustomerButton.click();

	    WebElement nameField = driver.findElement(By.id("customerName"));
	    WebElement emailField = driver.findElement(By.id("customerEmail"));
	    WebElement saveButton = driver.findElement(By.id("saveCustomerButton"));

	    nameField.clear();
	    nameField.sendKeys(customerName);
	    emailField.clear();
	    emailField.sendKeys(customerEmail);
	    saveButton.click();

	    WebElement successMessage = driver.findElement(By.id("successMessage"));
	    Assert.assertTrue(successMessage.isDisplayed(), "Customer addition failed for: " + customerName);
	    Assert.assertEquals(successMessage.getText(), "Customer added successfully", "Unexpected success message.");
	}


}
