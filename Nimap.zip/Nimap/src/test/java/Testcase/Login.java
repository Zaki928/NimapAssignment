package Testcase;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


public class Login {
	

	    WebDriver driver;

	    @Test(dataProvider = "loginData")
	    public void testLogin(String username, String password, boolean expectedResult) {
	    	
	    	WebDriverManager.chromedriver().setup();
			WebDriver driver=new ChromeDriver();
	        driver = new ChromeDriver();
	        driver.get(" https://testffc.nimapinfotech.com/");

	        driver.findElement(By.xpath("//*[@placeholder=\"Email Id / Mobile No\"]")).sendKeys("abc@gmail.com");
	        driver.findElement(By.xpath("//*[@placeholder=\"Password\"]")).sendKeys("1234");
	        driver.findElement(By.xpath("//*[@formcontrolname=\"captchaValue\"]")).sendKeys("IIACF6");
	        driver.findElement(By.id("(//*[@class=\"btn btn-primary btn-elevate kt-login__btn-primary\"])[1]")).click();
	        driver.quit();
	    }

	    @DataProvider(name = "loginData")
	    public Object[][] loginData() {
	        return new Object[][] {
	            {"abc@123", "abc1234", true},
	            {"bro@123", "bro123456", false}
	        };
	    }
	
	
	

	

}
